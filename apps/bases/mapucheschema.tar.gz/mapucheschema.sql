--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Ubuntu 15.4-1ubuntu1)
-- Dumped by pg_dump version 15.4 (Ubuntu 15.4-1ubuntu1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: mapuche; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA mapuche;


ALTER SCHEMA mapuche OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: logs_dh03333; Type: TABLE; Schema: mapuche; Owner: postgres
--

CREATE TABLE mapuche.logs_dh03333 (
    id_log integer NOT NULL,
    auditoria_usuario character varying(30),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    nro_cargo integer,
    rama character(4),
    disciplina character(4),
    area character(4),
    porcdedicdocente double precision DEFAULT 0,
    porcdedicinvestig double precision DEFAULT 0,
    porcdedicagestion double precision DEFAULT 0,
    porcdedicaextens double precision DEFAULT 0,
    codigocontrato integer DEFAULT 0,
    horassemanales double precision DEFAULT 0,
    duracioncontrato integer DEFAULT 0,
    incisoimputacion character(5),
    montocontrato double precision DEFAULT 0,
    nro_legaj integer,
    fec_alta date,
    fec_baja date,
    codc_carac character(4),
    codc_categ character(4),
    codc_agrup character(4),
    tipo_norma character(20),
    tipo_emite character(20),
    fec_norma date,
    nro_norma integer,
    codc_secex character(4),
    nro_exped character(20),
    nro_exped_baja character(20),
    fec_exped_baja date,
    ano_exped_baja integer DEFAULT 0,
    codc_secex_baja character(4),
    ano_exped integer DEFAULT 0,
    fec_exped date,
    nro_tab13 integer DEFAULT 13,
    codc_uacad character(4),
    nro_tab18 integer DEFAULT 18,
    codc_regio character(4),
    codc_grado character(4),
    vig_caano integer,
    vig_cames integer,
    chk_proye boolean DEFAULT true,
    tipo_incen character(1),
    dedi_incen character(4),
    cic_con character(3),
    fec_limite date,
    porc_aplic double precision,
    hs_dedic double precision,
    tipo_norma_baja character(20),
    tipoemitenormabaja character(20),
    fecha_norma_baja date,
    fechanotificacion date,
    coddependesemp character(4),
    chkfirmaencargado integer DEFAULT 0,
    chkfirmaautoridad integer DEFAULT 0,
    chkestadoafip integer DEFAULT 0,
    chkestadotitulo integer DEFAULT 0,
    chkestadocv integer DEFAULT 0,
    objetocontrato character varying(30),
    nro_norma_baja integer DEFAULT 0,
    fechagrado date,
    fechapermanencia date,
    fecaltadesig date,
    fecbajadesig date,
    motivoaltadesig integer DEFAULT 0,
    motivobajadesig integer DEFAULT 0,
    renovacion character(20),
    idtareacargo integer,
    chktrayectoria boolean DEFAULT true,
    chkfuncionejec boolean DEFAULT false,
    chkretroactivo boolean DEFAULT false,
    chkstopliq integer DEFAULT 0,
    nro_cargo_ant integer DEFAULT 0,
    transito integer DEFAULT 0,
    cod_clasif_cargo integer,
    cod_licencia integer,
    cargo_concursado boolean DEFAULT false
);


ALTER TABLE mapuche.logs_dh03333 OWNER TO postgres;

--
-- Name: logs_dh03333_id_log_seq; Type: SEQUENCE; Schema: mapuche; Owner: postgres
--

CREATE SEQUENCE mapuche.logs_dh03333_id_log_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mapuche.logs_dh03333_id_log_seq OWNER TO postgres;

--
-- Name: logs_dh03333_id_log_seq; Type: SEQUENCE OWNED BY; Schema: mapuche; Owner: postgres
--

ALTER SEQUENCE mapuche.logs_dh03333_id_log_seq OWNED BY mapuche.logs_dh03333.id_log;


--
-- Name: logs_dh03333 id_log; Type: DEFAULT; Schema: mapuche; Owner: postgres
--

ALTER TABLE ONLY mapuche.logs_dh03333 ALTER COLUMN id_log SET DEFAULT nextval('mapuche.logs_dh03333_id_log_seq'::regclass);


--
-- Data for Name: logs_dh03333; Type: TABLE DATA; Schema: mapuche; Owner: postgres
--

COPY mapuche.logs_dh03333 (id_log, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud, nro_cargo, rama, disciplina, area, porcdedicdocente, porcdedicinvestig, porcdedicagestion, porcdedicaextens, codigocontrato, horassemanales, duracioncontrato, incisoimputacion, montocontrato, nro_legaj, fec_alta, fec_baja, codc_carac, codc_categ, codc_agrup, tipo_norma, tipo_emite, fec_norma, nro_norma, codc_secex, nro_exped, nro_exped_baja, fec_exped_baja, ano_exped_baja, codc_secex_baja, ano_exped, fec_exped, nro_tab13, codc_uacad, nro_tab18, codc_regio, codc_grado, vig_caano, vig_cames, chk_proye, tipo_incen, dedi_incen, cic_con, fec_limite, porc_aplic, hs_dedic, tipo_norma_baja, tipoemitenormabaja, fecha_norma_baja, fechanotificacion, coddependesemp, chkfirmaencargado, chkfirmaautoridad, chkestadoafip, chkestadotitulo, chkestadocv, objetocontrato, nro_norma_baja, fechagrado, fechapermanencia, fecaltadesig, fecbajadesig, motivoaltadesig, motivobajadesig, renovacion, idtareacargo, chktrayectoria, chkfuncionejec, chkretroactivo, chkstopliq, nro_cargo_ant, transito, cod_clasif_cargo, cod_licencia, cargo_concursado) FROM stdin;
\.


--
-- Name: logs_dh03333_id_log_seq; Type: SEQUENCE SET; Schema: mapuche; Owner: postgres
--

SELECT pg_catalog.setval('mapuche.logs_dh03333_id_log_seq', 195293, true);


--
-- PostgreSQL database dump complete
--

